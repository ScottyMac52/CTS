SnapViews = {}
SnapViews["A-10A"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -26.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 49.626770,--FOV
		hAngle			= 0.000000,
		vAngle			= -90.631294,
		x_trans			= 0.180499,
		y_trans			= -0.137064,
		z_trans			= -0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 30.395041,--FOV
		hAngle			= 0.000000,
		vAngle			= -94.329208,
		x_trans			= 0.372718,
		y_trans			= -0.054055,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 55.238567,--FOV
		hAngle			= 0.000000,
		vAngle			= -90.631294,
		x_trans			= 0.158523,
		y_trans			= -0.137064,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 35.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -10.651850,
		x_trans			= 0.327622,
		y_trans			= -0.278207,
		z_trans			= -0.244799,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 34.340549,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 35.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -10.651850,
		x_trans			= 0.327622,
		y_trans			= -0.278207,
		z_trans			= 0.244799,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 68.628296,--FOV
		hAngle			= 68.292320,
		vAngle			= -11.477349,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 68.628296,--FOV
		hAngle			= 0.000000,
		vAngle			= 30.227919,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 68.628296,--FOV
		hAngle			= -67.172974,
		vAngle			= -11.477349,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 70.000000,--FOV
		hAngle			= 20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 70.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["A-10C"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -26.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 63.740002,--FOV
		hAngle			= 70.197182,
		vAngle			= -58.828632,
		x_trans			= 0.126559,
		y_trans			= -0.052729,
		z_trans			= -0.071945,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 51.796501,--FOV
		hAngle			= -59.177437,
		vAngle			= -62.901718,
		x_trans			= 0.088538,
		y_trans			= 0.036120,
		z_trans			= 0.059352,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 32.296501,--FOV
		hAngle			= 0.000000,
		vAngle			= -80.000000,
		x_trans			= 0.183838,
		y_trans			= 0.014481,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 76.511101,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.000000,
		x_trans			= 0.402969,
		y_trans			= -0.256181,
		z_trans			= -0.117188,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 82.227150,--FOV
		hAngle			= 0.000000,
		vAngle			= -21.213251,
		x_trans			= 0.351388,
		y_trans			= -0.259055,
		z_trans			= -0.001991,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 78.674400,--FOV
		hAngle			= 0.000000,
		vAngle			= -26.371302,
		x_trans			= 0.402969,
		y_trans			= -0.264311,
		z_trans			= 0.122662,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 68.982597,--FOV
		hAngle			= 0.000000,
		vAngle			= -62.194908,
		x_trans			= 0.237730,
		y_trans			= -0.300000,
		z_trans			= -0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 74.182503,--FOV
		hAngle			= 0.000000,
		vAngle			= -0.220625,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 68.982597,--FOV
		hAngle			= -1.941612,
		vAngle			= -67.146278,
		x_trans			= 0.396876,
		y_trans			= -0.300000,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[11] = {--look at left  mirror
		viewAngle		= 70.000000,--FOV
		hAngle			= 20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[12] = {--look at right mirror
		viewAngle		= 70.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[13] = {--default view
		viewAngle		= 73.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.000000,
		x_trans			= 0.150000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[14] = {--default view - VR
		viewAngle		= 73.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.000000,
		x_trans			= 0.150000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
},
}
SnapViews["A-10C_2"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -26.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 63.740002,--FOV
		hAngle			= 70.197182,
		vAngle			= -58.828632,
		x_trans			= 0.126559,
		y_trans			= -0.052729,
		z_trans			= -0.071945,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 51.796501,--FOV
		hAngle			= -59.177437,
		vAngle			= -62.901718,
		x_trans			= 0.088538,
		y_trans			= 0.036120,
		z_trans			= 0.059352,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 32.296501,--FOV
		hAngle			= 0.000000,
		vAngle			= -80.000000,
		x_trans			= 0.183838,
		y_trans			= 0.014481,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 76.511101,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.000000,
		x_trans			= 0.402969,
		y_trans			= -0.256181,
		z_trans			= -0.117188,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 82.227150,--FOV
		hAngle			= 0.000000,
		vAngle			= -21.213251,
		x_trans			= 0.351388,
		y_trans			= -0.259055,
		z_trans			= -0.001991,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 78.674400,--FOV
		hAngle			= 0.000000,
		vAngle			= -26.371302,
		x_trans			= 0.402969,
		y_trans			= -0.264311,
		z_trans			= 0.122662,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 68.982597,--FOV
		hAngle			= 0.000000,
		vAngle			= -62.194908,
		x_trans			= 0.237730,
		y_trans			= -0.300000,
		z_trans			= -0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 74.182503,--FOV
		hAngle			= 0.000000,
		vAngle			= -0.220625,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 68.982597,--FOV
		hAngle			= -1.941612,
		vAngle			= -67.146278,
		x_trans			= 0.396876,
		y_trans			= -0.300000,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[11] = {--look at left  mirror
		viewAngle		= 70.000000,--FOV
		hAngle			= 20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[12] = {--look at right mirror
		viewAngle		= 70.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.360000,
		y_trans			= -0.041337,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[13] = {--default view			
		viewAngle		= 73.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.000000,
		x_trans			= 0.298000,
		y_trans			= -0.041000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
	[14] = {--default view - VR
		viewAngle		= 73.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.000000,
		x_trans			= 0.298000,
		y_trans			= -0.041000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 1,
	},
},
}
SnapViews["A-4E-C"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 70.611748,--FOV
		hAngle			= -1.240272,
		vAngle			= 0.850250,
		x_trans			= 0.164295,
		y_trans			= -0.074373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 32.704346,--FOV
		hAngle			= 25.696522,
		vAngle			= -34.778103,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 32.704346,--FOV
		hAngle			= 0.000000,
		vAngle			= -47.845268,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 44.474998,--FOV
		hAngle			= -50.453411,
		vAngle			= -52.185158,
		x_trans			= 0.127801,
		y_trans			= -0.112737,
		z_trans			= 0.043057,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 88.727844,--FOV
		hAngle			= 128.508865,
		vAngle			= 13.131046,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 41.928593,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.630446,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 88.727844,--FOV
		hAngle			= -128.508865,
		vAngle			= 13.131046,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 88.727844,--FOV
		hAngle			= 81.648369,
		vAngle			= -9.500000,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.180634,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 88.727844,--FOV
		hAngle			= -80.997551,
		vAngle			= -9.500000,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["AH-64D_BLK_II"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 76.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -10.000000,
		x_trans			= -0.142000,
		y_trans			= 0.070000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 65.480000,--FOV
		hAngle			= 61.089742,
		vAngle			= -69.100116,
		x_trans			= -0.048506,
		y_trans			= 0.070000,
		z_trans			= -0.270776,
		rollAngle		= -0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 20.000000,--FOV
		hAngle			= 33.250581,
		vAngle			= -43.550708,
		x_trans			= -0.142000,
		y_trans			= -0.014639,
		z_trans			= -0.129328,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 65.480000,--FOV
		hAngle			= -6.220994,
		vAngle			= -25.911396,
		x_trans			= -0.142000,
		y_trans			= 0.006579,
		z_trans			= 0.147387,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 48.899350,--FOV
		hAngle			= 0.833029,
		vAngle			= -30.720423,
		x_trans			= -0.142000,
		y_trans			= -0.008768,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 76.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -10.000000,
		x_trans			= -0.142000,
		y_trans			= 0.070000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 76.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -10.000000,
		x_trans			= -0.142000,
		y_trans			= 0.070000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 76.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -5.000000,
		x_trans			= -0.142000,
		y_trans			= 0.070000,
		z_trans			= -0.057500,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 62.200000,--FOV
		hAngle			= 89.282297,
		vAngle			= -61.604800,
		x_trans			= 0.263179,
		y_trans			= 0.070000,
		z_trans			= -0.197842,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 20.000000,--FOV
		hAngle			= 18.173132,
		vAngle			= -42.565391,
		x_trans			= -0.122639,
		y_trans			= 0.050261,
		z_trans			= -0.224654,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 67.109950,--FOV
		hAngle			= -11.145995,
		vAngle			= -31.831238,
		x_trans			= -0.142000,
		y_trans			= 0.038028,
		z_trans			= 0.071936,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 38.285450,--FOV
		hAngle			= -0.218889,
		vAngle			= -27.557433,
		x_trans			= -0.142000,
		y_trans			= 0.070000,
		z_trans			= -0.038099,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 76.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -5.000000,
		x_trans			= -0.142000,
		y_trans			= 0.070000,
		z_trans			= -0.057500,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 76.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -5.000000,
		x_trans			= 0.078000,
		y_trans			= 0.070000,
		z_trans			= -0.057500,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["AJS37"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 70.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 72.253899,--FOV
		hAngle			= 41.814491,
		vAngle			= -45.705864,
		x_trans			= 0.282970,
		y_trans			= -0.349799,
		z_trans			= -0.117038,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 54.220001,--FOV
		hAngle			= -63.825424,
		vAngle			= -46.844791,
		x_trans			= 0.215962,
		y_trans			= -0.028601,
		z_trans			= -0.021436,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 72.253899,--FOV
		hAngle			= 106.680771,
		vAngle			= -45.705864,
		x_trans			= 0.355465,
		y_trans			= -0.328047,
		z_trans			= -0.109574,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 76.376801,--FOV
		hAngle			= -74.538521,
		vAngle			= -53.254993,
		x_trans			= 0.000000,
		y_trans			= -0.342583,
		z_trans			= 0.183635,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.115000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["AV8BNA"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 48.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 48.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 45.429688,--FOV
		hAngle			= 0.000000,
		vAngle			= -41.851212,
		x_trans			= 0.000000,
		y_trans			= -0.096696,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 48.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 46.835938,--FOV
		hAngle			= 74.637932,
		vAngle			= -61.458694,
		x_trans			= 0.017300,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 38.398438,--FOV
		hAngle			= -60.077934,
		vAngle			= -62.696346,
		x_trans			= 0.017300,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 96.790771,--FOV
		hAngle			= 96.895103,
		vAngle			= 0.468915,
		x_trans			= 0.030013,
		y_trans			= 0.010000,
		z_trans			= -0.001808,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 56.735001,--FOV
		hAngle			= 0.221911,
		vAngle			= -16.368570,
		x_trans			= -0.001207,
		y_trans			= -0.087683,
		z_trans			= -0.136578,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 41.093750,--FOV
		hAngle			= -5.003126,
		vAngle			= -12.002639,
		x_trans			= -0.049369,
		y_trans			= 0.007837,
		z_trans			= 0.073089,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Bf-109K-4"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.807243,--FOV
		hAngle			= -5.775880,
		vAngle			= -5.098398,
		x_trans			= 0.110856,
		y_trans			= -0.089071,
		z_trans			= 0.169801,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 49.400002,--FOV
		hAngle			= -62.839272,
		vAngle			= -16.547632,
		x_trans			= 0.260034,
		y_trans			= -0.320000,
		z_trans			= -0.145330,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.006650,
		z_trans			= 0.061980,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["C-101CC"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 49.169998,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.048433,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 58.259998,--FOV
		hAngle			= 109.827484,
		vAngle			= -51.599998,
		x_trans			= 0.236410,
		y_trans			= 0.000000,
		z_trans			= 0.055893,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 29.719999,--FOV
		hAngle			= 19.873764,
		vAngle			= -51.485748,
		x_trans			= 0.034963,
		y_trans			= 0.000000,
		z_trans			= 0.203612,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 57.480000,--FOV
		hAngle			= -67.117027,
		vAngle			= -50.906132,
		x_trans			= 0.024574,
		y_trans			= -0.099031,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 57.480000,--FOV
		hAngle			= 34.436771,
		vAngle			= -37.376457,
		x_trans			= 0.024574,
		y_trans			= -0.099031,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -22.792200,
		x_trans			= 0.000000,
		y_trans			= -0.097650,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 50.700001,--FOV
		hAngle			= -21.357298,
		vAngle			= -30.668098,
		x_trans			= 0.024574,
		y_trans			= -0.099995,
		z_trans			= 0.031663,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= -0.057547,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 56.338348,--FOV
		hAngle			= 83.998840,
		vAngle			= -56.973473,
		x_trans			= 0.062819,
		y_trans			= 0.012961,
		z_trans			= 0.000220,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 47.020500,--FOV
		hAngle			= 6.181208,
		vAngle			= -35.059681,
		x_trans			= 0.000000,
		y_trans			= -0.010331,
		z_trans			= 0.176109,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 56.338348,--FOV
		hAngle			= -67.312019,
		vAngle			= -47.689495,
		x_trans			= 0.199786,
		y_trans			= -0.095705,
		z_trans			= -0.006039,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 57.480000,--FOV
		hAngle			= 34.436771,
		vAngle			= -37.376457,
		x_trans			= 0.024574,
		y_trans			= -0.099031,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 56.338348,--FOV
		hAngle			= 0.000000,
		vAngle			= -22.237185,
		x_trans			= -0.043750,
		y_trans			= -0.099950,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 50.700001,--FOV
		hAngle			= -21.357298,
		vAngle			= -30.668098,
		x_trans			= 0.024574,
		y_trans			= -0.099995,
		z_trans			= 0.031663,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= -0.054960,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["C-101EB"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 49.169998,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.048433,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 58.259998,--FOV
		hAngle			= 109.827484,
		vAngle			= -51.599998,
		x_trans			= 0.236410,
		y_trans			= 0.000000,
		z_trans			= 0.055893,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 29.719999,--FOV
		hAngle			= 19.873764,
		vAngle			= -51.485748,
		x_trans			= 0.034963,
		y_trans			= 0.000000,
		z_trans			= 0.203612,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 57.480000,--FOV
		hAngle			= -67.117027,
		vAngle			= -50.906132,
		x_trans			= 0.024574,
		y_trans			= -0.099031,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 57.480000,--FOV
		hAngle			= 34.436771,
		vAngle			= -37.376457,
		x_trans			= 0.024574,
		y_trans			= -0.099031,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 47.020500,--FOV
		hAngle			= 6.181208,
		vAngle			= -35.059681,
		x_trans			= 0.000000,
		y_trans			= -0.010331,
		z_trans			= 0.176109,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 50.700001,--FOV
		hAngle			= -21.357298,
		vAngle			= -30.668098,
		x_trans			= 0.024574,
		y_trans			= -0.099995,
		z_trans			= 0.031663,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.130800,
		x_trans			= 0.000000,
		y_trans			= -0.071550,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 52.354252,--FOV
		hAngle			= 83.666893,
		vAngle			= -58.314083,
		x_trans			= 0.044427,
		y_trans			= 0.000000,
		z_trans			= -0.030493,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 52.354252,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.580940,
		x_trans			= -0.047136,
		y_trans			= -0.096089,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 52.354252,--FOV
		hAngle			= -64.831879,
		vAngle			= -51.778931,
		x_trans			= 0.096657,
		y_trans			= 0.000000,
		z_trans			= -0.031788,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 57.480000,--FOV
		hAngle			= 34.436771,
		vAngle			= -37.376457,
		x_trans			= 0.024574,
		y_trans			= -0.099031,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 52.354252,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.580940,
		x_trans			= -0.047136,
		y_trans			= -0.096089,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 50.700001,--FOV
		hAngle			= -21.357298,
		vAngle			= -30.668098,
		x_trans			= 0.024574,
		y_trans			= -0.099995,
		z_trans			= 0.031663,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.130800,
		x_trans			= 0.000000,
		y_trans			= -0.071550,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-14A-135-GR"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 50.000000,--FOV
		hAngle			= 3.500000,
		vAngle			= 33.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 63.445000,--FOV
		hAngle			= 88.973450,
		vAngle			= -55.114746,
		x_trans			= 0.113601,
		y_trans			= -0.393798,
		z_trans			= -0.145416,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 50.042549,--FOV
		hAngle			= -56.744251,
		vAngle			= -58.072994,
		x_trans			= -0.191938,
		y_trans			= -0.150070,
		z_trans			= 0.087255,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 85.000000,--FOV
		hAngle			= 80.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 85.000000,--FOV
		hAngle			= -80.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= 0.085000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= 0.085000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 70.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 54.169922,--FOV
		hAngle			= 28.066311,
		vAngle			= -66.293983,
		x_trans			= -0.104727,
		y_trans			= -0.166346,
		z_trans			= -0.142244,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -27.812515,
		x_trans			= 0.151293,
		y_trans			= -0.390212,
		z_trans			= -0.028800,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 54.133202,--FOV
		hAngle			= -52.205814,
		vAngle			= -60.981667,
		x_trans			= -0.098198,
		y_trans			= -0.195752,
		z_trans			= 0.111434,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 106.389900,--FOV
		hAngle			= 11.576250,
		vAngle			= -34.915833,
		x_trans			= 0.222747,
		y_trans			= -0.397848,
		z_trans			= -0.117524,
		rollAngle		= -0.637207,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 54.169922,--FOV
		hAngle			= -33.305218,
		vAngle			= -42.020531,
		x_trans			= -0.037501,
		y_trans			= -0.355620,
		z_trans			= 0.121313,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 54.023438,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= -0.020000,
		y_trans			= -0.181306,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= -0.020000,
		y_trans			= -0.040000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= -0.020000,
		y_trans			= -0.040000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-14B"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 50.000000,--FOV
		hAngle			= 3.500000,
		vAngle			= 33.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 63.445000,--FOV
		hAngle			= 88.973450,
		vAngle			= -55.114746,
		x_trans			= 0.113601,
		y_trans			= -0.393798,
		z_trans			= -0.145416,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 50.042549,--FOV
		hAngle			= -56.744251,
		vAngle			= -58.072994,
		x_trans			= -0.191938,
		y_trans			= -0.150070,
		z_trans			= 0.087255,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 85.000000,--FOV
		hAngle			= 80.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 85.000000,--FOV
		hAngle			= -80.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= 0.085000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= 0.085000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 70.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 54.169922,--FOV
		hAngle			= 28.066311,
		vAngle			= -66.293983,
		x_trans			= -0.104727,
		y_trans			= -0.166346,
		z_trans			= -0.142244,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -27.812515,
		x_trans			= 0.151293,
		y_trans			= -0.390212,
		z_trans			= -0.028800,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 54.133202,--FOV
		hAngle			= -52.205814,
		vAngle			= -60.981667,
		x_trans			= -0.098198,
		y_trans			= -0.195752,
		z_trans			= 0.111434,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 106.389900,--FOV
		hAngle			= 11.576250,
		vAngle			= -34.915833,
		x_trans			= 0.222747,
		y_trans			= -0.397848,
		z_trans			= -0.117524,
		rollAngle		= -0.637207,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 54.169922,--FOV
		hAngle			= -33.305218,
		vAngle			= -42.020531,
		x_trans			= -0.037501,
		y_trans			= -0.355620,
		z_trans			= 0.121313,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 54.023438,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= -0.020000,
		y_trans			= -0.181306,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= -0.020000,
		y_trans			= -0.040000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.000000,
		x_trans			= -0.020000,
		y_trans			= -0.040000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-15C"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 70.611748,--FOV
		hAngle			= -1.240272,
		vAngle			= -33.850250,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 32.704346,--FOV
		hAngle			= 25.696522,
		vAngle			= -34.778103,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 32.704346,--FOV
		hAngle			= 0.000000,
		vAngle			= -47.845268,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 36.106045,--FOV
		hAngle			= -28.878576,
		vAngle			= -36.780628,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 88.727844,--FOV
		hAngle			= 128.508865,
		vAngle			= 13.131046,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 41.928593,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.630446,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 88.727844,--FOV
		hAngle			= -128.508865,
		vAngle			= 13.131046,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 88.727844,--FOV
		hAngle			= 81.648369,
		vAngle			= -9.500000,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.180634,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 88.727844,--FOV
		hAngle			= -80.997551,
		vAngle			= -9.500000,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.678451,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.678451,
		x_trans			= 0.264295,
		y_trans			= -0.064373,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-15ESE"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 48.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 51.823101,--FOV
		hAngle			= 69.300095,
		vAngle			= -52.996445,
		x_trans			= 0.000000,
		y_trans			= -0.053821,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 51.823101,--FOV
		hAngle			= 0.000000,
		vAngle			= -27.860195,
		x_trans			= 0.000000,
		y_trans			= -0.099436,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 45.283100,--FOV
		hAngle			= -49.079956,
		vAngle			= -48.595585,
		x_trans			= 0.000000,
		y_trans			= -0.099924,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.040001,--FOV
		hAngle			= 157.332764,
		vAngle			= -28.359503,
		x_trans			= 0.063872,
		y_trans			= 0.082888,
		z_trans			= -0.116148,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -143.000000,
		vAngle			= 0.000000,
		x_trans			= 0.350000,
		y_trans			= 0.020000,
		z_trans			= 0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 49.314350,--FOV
		hAngle			= 0.000000,
		vAngle			= -19.262856,
		x_trans			= 0.000000,
		y_trans			= -0.046113,
		z_trans			= -0.000427,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.383367,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 48.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 30.919813,--FOV
		hAngle			= -0.217673,
		vAngle			= -28.964834,
		x_trans			= 0.000000,
		y_trans			= -0.009639,
		z_trans			= -0.179215,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 35.188438,--FOV
		hAngle			= -19.809000,
		vAngle			= -39.977650,
		x_trans			= 0.000000,
		y_trans			= -0.100000,
		z_trans			= 0.128672,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 30.919813,--FOV
		hAngle			= -0.217623,
		vAngle			= -28.966305,
		x_trans			= 0.000000,
		y_trans			= -0.009028,
		z_trans			= 0.177716,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.040001,--FOV
		hAngle			= 157.332764,
		vAngle			= -28.359503,
		x_trans			= 0.063872,
		y_trans			= 0.082888,
		z_trans			= -0.116148,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -143.000000,
		vAngle			= 0.000000,
		x_trans			= 0.350000,
		y_trans			= 0.020000,
		z_trans			= 0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 59.799500,--FOV
		hAngle			= 0.000000,
		vAngle			= -25.363230,
		x_trans			= 0.000000,
		y_trans			= -0.099578,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-16C_50"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.021000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 47.292435,--FOV
		hAngle			= 48.871532,
		vAngle			= -27.210711,
		x_trans			= 0.249971,
		y_trans			= -0.084290,
		z_trans			= 0.073930,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 55.221584,--FOV
		hAngle			= 16.238178,
		vAngle			= -30.736124,
		x_trans			= -0.050000,
		y_trans			= 0.023570,
		z_trans			= 0.169352,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 42.162884,--FOV
		hAngle			= -56.690430,
		vAngle			= -28.339693,
		x_trans			= 0.198301,
		y_trans			= -0.113795,
		z_trans			= -0.169444,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 53.281250,--FOV
		hAngle			= 103.429100,
		vAngle			= -65.572777,
		x_trans			= 0.117690,
		y_trans			= 0.081319,
		z_trans			= -0.082923,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.021000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 53.281250,--FOV
		hAngle			= -80.750145,
		vAngle			= -58.404755,
		x_trans			= 0.029359,
		y_trans			= 0.083000,
		z_trans			= 0.044594,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 99.106483,--FOV
		hAngle			= 131.835434,
		vAngle			= -7.700000,
		x_trans			= 0.116748,
		y_trans			= 0.040000,
		z_trans			= -0.063734,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 45.847183,--FOV
		hAngle			= -67.158295,
		vAngle			= -34.341640,
		x_trans			= -0.047527,
		y_trans			= -0.149968,
		z_trans			= -0.169835,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.021000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.021000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.021000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.021000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.130000,
		y_trans			= 0.083000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-5E-3"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 47.292435,--FOV
		hAngle			= 48.871532,
		vAngle			= -27.210711,
		x_trans			= 0.249971,
		y_trans			= -0.084290,
		z_trans			= 0.073930,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 58.389851,--FOV
		hAngle			= 16.320631,
		vAngle			= -29.974707,
		x_trans			= 0.000000,
		y_trans			= -0.046486,
		z_trans			= 0.189893,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 42.162884,--FOV
		hAngle			= -56.690430,
		vAngle			= -28.339693,
		x_trans			= 0.198301,
		y_trans			= -0.113795,
		z_trans			= -0.169444,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 64.821587,--FOV
		hAngle			= 112.844025,
		vAngle			= -38.512653,
		x_trans			= 0.192144,
		y_trans			= -0.149974,
		z_trans			= 0.148975,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 55.734432,--FOV
		hAngle			= -135.255219,
		vAngle			= -34.517639,
		x_trans			= 0.000000,
		y_trans			= -0.149154,
		z_trans			= -0.040000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 99.106483,--FOV
		hAngle			= 131.835434,
		vAngle			= -7.700000,
		x_trans			= 0.116748,
		y_trans			= 0.040000,
		z_trans			= -0.063734,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 46.654900,--FOV
		hAngle			= -37.448410,
		vAngle			= -56.136620,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.096064,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= -0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["F-86F Sabre"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 48.534401,--FOV
		hAngle			= 63.569427,
		vAngle			= -50.142502,
		x_trans			= -0.059105,
		y_trans			= -0.149068,
		z_trans			= 0.010142,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 38.320000,--FOV
		hAngle			= 14.831400,
		vAngle			= -40.406082,
		x_trans			= -0.059143,
		y_trans			= -0.149610,
		z_trans			= 0.298932,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 40.875401,--FOV
		hAngle			= -35.221874,
		vAngle			= -53.056213,
		x_trans			= -0.147010,
		y_trans			= 0.002542,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 39.400002,--FOV
		hAngle			= 15.853048,
		vAngle			= -6.904122,
		x_trans			= -0.059135,
		y_trans			= -0.149501,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.053361,
		y_trans			= -0.066925,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["FA-18C_hornet"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.700000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 73.203125,--FOV
		hAngle			= 72.141769,
		vAngle			= -52.583687,
		x_trans			= 0.158168,
		y_trans			= -0.177568,
		z_trans			= -0.017484,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.078125,--FOV
		hAngle			= 0.000000,
		vAngle			= -31.713167,
		x_trans			= 0.130000,
		y_trans			= -0.299986,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 68.281250,--FOV
		hAngle			= -58.240002,
		vAngle			= -50.403198,
		x_trans			= 0.130000,
		y_trans			= -0.165633,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 64.821587,--FOV
		hAngle			= 112.844025,
		vAngle			= -38.512653,
		x_trans			= 0.192144,
		y_trans			= -0.149974,
		z_trans			= 0.148975,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.700000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 45.847183,--FOV
		hAngle			= -67.158295,
		vAngle			= -34.341640,
		x_trans			= -0.047527,
		y_trans			= -0.149968,
		z_trans			= -0.169835,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 99.106483,--FOV
		hAngle			= 131.835434,
		vAngle			= -7.700000,
		x_trans			= 0.116748,
		y_trans			= 0.040000,
		z_trans			= -0.063734,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 55.976563,--FOV
		hAngle			= 3.953275,
		vAngle			= -13.716000,
		x_trans			= 0.137904,
		y_trans			= -0.201627,
		z_trans			= -0.015025,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.700000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.700000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 63.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.700000,
		x_trans			= 0.130000,
		y_trans			= -0.008300,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["FW-190A8"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 57.298576,--FOV
		hAngle			= 38.818359,
		vAngle			= -48.831055,
		x_trans			= -0.050000,
		y_trans			= 0.050000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 62.910477,--FOV
		hAngle			= 0.732422,
		vAngle			= -8.181641,
		x_trans			= -0.050000,
		y_trans			= -0.266772,
		z_trans			= 0.002441,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 48.509514,--FOV
		hAngle			= -46.875000,
		vAngle			= -52.676270,
		x_trans			= -0.050000,
		y_trans			= 0.050000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.488602,--FOV
		hAngle			= 144.287109,
		vAngle			= -3.237793,
		x_trans			= 0.152988,
		y_trans			= 0.050000,
		z_trans			= -0.104069,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.995071,--FOV
		hAngle			= -1.220703,
		vAngle			= 0.167969,
		x_trans			= 0.023242,
		y_trans			= 0.003613,
		z_trans			= 0.036011,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 48.783798,--FOV
		hAngle			= -94.776123,
		vAngle			= -69.166481,
		x_trans			= 0.192021,
		y_trans			= 0.029251,
		z_trans			= 0.039410,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.488602,--FOV
		hAngle			= 43.212891,
		vAngle			= -1.919434,
		x_trans			= -0.050000,
		y_trans			= 0.050000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 48.783798,--FOV
		hAngle			= -48.547356,
		vAngle			= -48.142014,
		x_trans			= 0.297735,
		y_trans			= -0.064952,
		z_trans			= 0.038542,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.609863,
		x_trans			= 0.056000,
		y_trans			= 0.015000,
		z_trans			= 0.039000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.609863,
		x_trans			= 0.056000,
		y_trans			= 0.015000,
		z_trans			= 0.039000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["FW-190D9"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 34.761600,--FOV
		hAngle			= -67.529137,
		vAngle			= -45.340115,
		x_trans			= 0.225079,
		y_trans			= -0.069096,
		z_trans			= -0.119887,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.002500,
		z_trans			= 0.037500,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.609863,
		x_trans			= -0.050000,
		y_trans			= 0.018884,
		z_trans			= 0.035561,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.609863,
		x_trans			= -0.050000,
		y_trans			= 0.018884,
		z_trans			= 0.035561,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Hawk"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 56.599400,--FOV
		hAngle			= 18.840424,
		vAngle			= -66.550468,
		x_trans			= 0.073070,
		y_trans			= 0.020000,
		z_trans			= -0.127553,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 36.496849,--FOV
		hAngle			= 16.254288,
		vAngle			= -39.268612,
		x_trans			= 0.213503,
		y_trans			= -0.096982,
		z_trans			= 0.299612,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 44.575401,--FOV
		hAngle			= -36.793442,
		vAngle			= -58.978775,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.098514,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 69.126801,--FOV
		hAngle			= 21.280001,
		vAngle			= -32.937737,
		x_trans			= 0.120000,
		y_trans			= -0.099733,
		z_trans			= -0.077092,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 54.362900,--FOV
		hAngle			= 0.000000,
		vAngle			= -39.268612,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.011944,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 63.992001,--FOV
		hAngle			= -25.248959,
		vAngle			= -27.217161,
		x_trans			= 0.120000,
		y_trans			= -0.097867,
		z_trans			= 0.068312,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["J-11A"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 71.824692,--FOV
		hAngle			= 0.000000,
		vAngle			= -32.458889,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 33.361835,--FOV
		hAngle			= 41.045925,
		vAngle			= -40.805656,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 30.427544,--FOV
		hAngle			= 0.000000,
		vAngle			= -41.808968,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 34.392349,--FOV
		hAngle			= -32.597401,
		vAngle			= -35.293747,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 87.468338,--FOV
		hAngle			= 129.012665,
		vAngle			= 14.547977,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 43.977936,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.951577,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 87.468338,--FOV
		hAngle			= -129.012665,
		vAngle			= 14.491872,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 87.468338,--FOV
		hAngle			= 82.862923,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= 38.979362,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 87.468338,--FOV
		hAngle			= -82.461266,
		vAngle			= -12.843998,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.786629,--FOV
		hAngle			= 15.618313,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 69.165199,--FOV
		hAngle			= -15.683434,
		vAngle			= 8.549150,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["JF-17"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.966202,--FOV
		hAngle			= 69.598534,
		vAngle			= -56.531757,
		x_trans			= 0.000000,
		y_trans			= 0.017641,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 48.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -75.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 50.945000,--FOV
		hAngle			= -63.126740,
		vAngle			= -59.258163,
		x_trans			= 0.000000,
		y_trans			= 0.017641,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.040001,--FOV
		hAngle			= 157.332764,
		vAngle			= -28.359503,
		x_trans			= 0.063872,
		y_trans			= 0.082888,
		z_trans			= -0.116148,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.966202,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.609416,
		x_trans			= -0.159051,
		y_trans			= -0.175482,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 41.756599,--FOV
		hAngle			= -22.213459,
		vAngle			= -54.283035,
		x_trans			= -0.026470,
		y_trans			= 0.017641,
		z_trans			= 0.096705,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 110.513542,--FOV
		hAngle			= 0.000000,
		vAngle			= -12.609416,
		x_trans			= 0.000000,
		y_trans			= 0.017641,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 114.165154,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.363433,
		x_trans			= 0.127094,
		y_trans			= 0.015877,
		z_trans			= -0.003428,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["KC130"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["KC135BDA"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["KC135MPRS"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["KJ-2000"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Ka-50"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 0.000000,
		vAngle			= -40.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 57.973751,--FOV
		hAngle			= 17.658089,
		vAngle			= -52.738251,
		x_trans			= -0.020000,
		y_trans			= 0.003724,
		z_trans			= -0.085936,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 48.639999,--FOV
		hAngle			= 1.070129,
		vAngle			= -33.833736,
		x_trans			= 0.004614,
		y_trans			= -0.149687,
		z_trans			= 0.088904,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 54.749100,--FOV
		hAngle			= -66.546440,
		vAngle			= -51.430557,
		x_trans			= -0.032464,
		y_trans			= -0.180000,
		z_trans			= -0.105038,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 43.160000,--FOV
		hAngle			= -17.397234,
		vAngle			= -61.325699,
		x_trans			= 0.120214,
		y_trans			= -0.150000,
		z_trans			= 0.111235,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 109.490051,--FOV
		hAngle			= -174.533813,
		vAngle			= -28.454536,
		x_trans			= 0.000000,
		y_trans			= -0.114531,
		z_trans			= 0.102526,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 62.323357,--FOV
		hAngle			= -0.150130,
		vAngle			= 12.937784,
		x_trans			= -0.059893,
		y_trans			= -0.066928,
		z_trans			= 0.022572,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 76.525803,--FOV
		hAngle			= -82.601044,
		vAngle			= -49.043747,
		x_trans			= 0.083085,
		y_trans			= -0.010878,
		z_trans			= 0.004126,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.592758,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.592758,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Ka-50_3"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 0.000000,
		vAngle			= -40.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 57.973751,--FOV
		hAngle			= 17.658089,
		vAngle			= -52.738251,
		x_trans			= -0.020000,
		y_trans			= 0.003724,
		z_trans			= -0.085936,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 48.639999,--FOV
		hAngle			= 1.070129,
		vAngle			= -33.833736,
		x_trans			= 0.004614,
		y_trans			= -0.149687,
		z_trans			= 0.088904,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 54.749100,--FOV
		hAngle			= -66.546440,
		vAngle			= -51.430557,
		x_trans			= -0.032464,
		y_trans			= -0.180000,
		z_trans			= -0.105038,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 43.160000,--FOV
		hAngle			= -17.397234,
		vAngle			= -61.325699,
		x_trans			= 0.120214,
		y_trans			= -0.150000,
		z_trans			= 0.111235,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 109.490051,--FOV
		hAngle			= -174.533813,
		vAngle			= -28.454536,
		x_trans			= 0.000000,
		y_trans			= -0.114531,
		z_trans			= 0.102526,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 62.323357,--FOV
		hAngle			= -0.150130,
		vAngle			= 12.937784,
		x_trans			= -0.059893,
		y_trans			= -0.066928,
		z_trans			= 0.022572,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 76.525803,--FOV
		hAngle			= -82.601044,
		vAngle			= -49.043747,
		x_trans			= 0.083085,
		y_trans			= -0.010878,
		z_trans			= 0.004126,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.592758,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.592758,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["L-39C"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 40.377548,--FOV
		hAngle			= 30.000000,
		vAngle			= -37.768734,
		x_trans			= 0.091525,
		y_trans			= -0.061150,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 29.440001,--FOV
		hAngle			= 21.750000,
		vAngle			= -56.526012,
		x_trans			= 0.163513,
		y_trans			= 0.076279,
		z_trans			= 0.215492,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 58.040001,--FOV
		hAngle			= -23.515549,
		vAngle			= -40.724113,
		x_trans			= 0.204141,
		y_trans			= -0.291187,
		z_trans			= 0.194058,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 45.847183,--FOV
		hAngle			= -67.158295,
		vAngle			= -34.341640,
		x_trans			= -0.047527,
		y_trans			= -0.149968,
		z_trans			= -0.169835,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 55.734432,--FOV
		hAngle			= -135.255219,
		vAngle			= -34.517639,
		x_trans			= 0.000000,
		y_trans			= -0.149154,
		z_trans			= -0.040000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 78.519997,--FOV
		hAngle			= 0.000000,
		vAngle			= -3.919462,
		x_trans			= 0.091525,
		y_trans			= 0.099975,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 65.279999,
		vAngle			= -30.161850,
		x_trans			= 0.057125,
		y_trans			= -0.383143,
		z_trans			= -0.072978,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 5.777867,
		x_trans			= 0.091525,
		y_trans			= 0.099942,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 50.495800,--FOV
		hAngle			= 29.561373,
		vAngle			= -45.315552,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 58.770050,--FOV
		hAngle			= 11.972434,
		vAngle			= -29.143044,
		x_trans			= 0.191305,
		y_trans			= -0.499852,
		z_trans			= 0.249738,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 33.261398,--FOV
		hAngle			= -20.213747,
		vAngle			= -35.947281,
		x_trans			= 0.049116,
		y_trans			= -0.301588,
		z_trans			= 0.142335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 50.959999,--FOV
		hAngle			= 72.452538,
		vAngle			= -42.313549,
		x_trans			= 0.088702,
		y_trans			= -0.442795,
		z_trans			= -0.082166,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 44.139999,--FOV
		hAngle			= -73.213173,
		vAngle			= -52.799770,
		x_trans			= 0.185257,
		y_trans			= 0.017665,
		z_trans			= -0.121122,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.398608,
		y_trans			= -0.049886,
		z_trans			= -0.245833,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 50.172100,--FOV
		hAngle			= 0.000000,
		vAngle			= -29.557779,
		x_trans			= 0.091525,
		y_trans			= -0.083500,
		z_trans			= -0.017742,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.398608,
		y_trans			= -0.049886,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["L-39ZA"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 62.166199,--FOV
		hAngle			= 25.791910,
		vAngle			= -37.891190,
		x_trans			= 0.171233,
		y_trans			= 0.001592,
		z_trans			= 0.028657,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 29.440001,--FOV
		hAngle			= 21.750000,
		vAngle			= -56.526012,
		x_trans			= 0.163513,
		y_trans			= 0.076279,
		z_trans			= 0.215492,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 58.040001,--FOV
		hAngle			= -23.515549,
		vAngle			= -40.724113,
		x_trans			= 0.204141,
		y_trans			= -0.291187,
		z_trans			= 0.194058,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 45.847183,--FOV
		hAngle			= -67.158295,
		vAngle			= -34.341640,
		x_trans			= -0.047527,
		y_trans			= -0.149968,
		z_trans			= -0.169835,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 55.734432,--FOV
		hAngle			= -135.255219,
		vAngle			= -34.517639,
		x_trans			= 0.000000,
		y_trans			= -0.149154,
		z_trans			= -0.040000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 78.519997,--FOV
		hAngle			= 0.000000,
		vAngle			= -3.919462,
		x_trans			= 0.091525,
		y_trans			= 0.099975,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 65.279999,
		vAngle			= -30.161850,
		x_trans			= 0.057125,
		y_trans			= -0.383143,
		z_trans			= -0.072978,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 5.777867,
		x_trans			= 0.091525,
		y_trans			= 0.099942,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 50.495800,--FOV
		hAngle			= 29.561373,
		vAngle			= -45.315552,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 58.770050,--FOV
		hAngle			= 11.972434,
		vAngle			= -29.143044,
		x_trans			= 0.191305,
		y_trans			= -0.499852,
		z_trans			= 0.249738,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 33.261398,--FOV
		hAngle			= -20.213747,
		vAngle			= -35.947281,
		x_trans			= 0.049116,
		y_trans			= -0.301588,
		z_trans			= 0.142335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 50.959999,--FOV
		hAngle			= 72.452538,
		vAngle			= -42.313549,
		x_trans			= 0.088702,
		y_trans			= -0.442795,
		z_trans			= -0.082166,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 44.139999,--FOV
		hAngle			= -73.213173,
		vAngle			= -52.799770,
		x_trans			= 0.185257,
		y_trans			= 0.017665,
		z_trans			= -0.121122,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.398608,
		y_trans			= -0.049886,
		z_trans			= -0.245833,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 50.172100,--FOV
		hAngle			= 0.000000,
		vAngle			= -29.557779,
		x_trans			= 0.091525,
		y_trans			= -0.083500,
		z_trans			= -0.017742,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.398608,
		y_trans			= -0.049886,
		z_trans			= 0.250000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 100.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.000000,
		x_trans			= 0.091525,
		y_trans			= 0.019003,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["M-2000C"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 48.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 43.763000,--FOV
		hAngle			= 22.083124,
		vAngle			= -42.849056,
		x_trans			= 0.072125,
		y_trans			= -0.020132,
		z_trans			= -0.002411,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 25.340704,--FOV
		hAngle			= 13.398186,
		vAngle			= -49.133217,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.199693,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 41.162750,--FOV
		hAngle			= -27.042133,
		vAngle			= -37.153873,
		x_trans			= -0.049939,
		y_trans			= -0.073708,
		z_trans			= 0.021161,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 56.119999,--FOV
		hAngle			= 62.095394,
		vAngle			= -61.293144,
		x_trans			= 0.136899,
		y_trans			= 0.000000,
		z_trans			= -0.016546,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 26.561000,--FOV
		hAngle			= 0.823542,
		vAngle			= -38.737775,
		x_trans			= 0.000000,
		y_trans			= -0.034330,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 48.799999,--FOV
		hAngle			= -62.251316,
		vAngle			= -59.229900,
		x_trans			= 0.136899,
		y_trans			= 0.000000,
		z_trans			= -0.016546,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MQ-9 Reaper"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Mi-24P"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 29.415312,--FOV
		hAngle			= -93.376801,
		vAngle			= 9.582571,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 98.373575,--FOV
		hAngle			= 80.865201,
		vAngle			= -29.371825,
		x_trans			= 0.122968,
		y_trans			= -0.285615,
		z_trans			= 0.081110,
		rollAngle		= -0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 67.605350,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.920300,
		x_trans			= 0.000000,
		y_trans			= 0.042777,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 81.069313,--FOV
		hAngle			= 0.352628,
		vAngle			= 62.929485,
		x_trans			= 0.000000,
		y_trans			= 0.135126,
		z_trans			= 0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 59.741261,--FOV
		hAngle			= 0.000000,
		vAngle			= 41.349342,
		x_trans			= 0.000000,
		y_trans			= -0.050205,
		z_trans			= -0.004188,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 28.216700,--FOV
		hAngle			= -76.491844,
		vAngle			= 9.112473,
		x_trans			= 0.000000,
		y_trans			= -0.050205,
		z_trans			= -0.024370,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 48.645350,--FOV
		hAngle			= -0.412346,
		vAngle			= -37.067219,
		x_trans			= -0.028758,
		y_trans			= 0.022860,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 71.837975,--FOV
		hAngle			= -88.718076,
		vAngle			= -50.623300,
		x_trans			= 0.223544,
		y_trans			= -0.156726,
		z_trans			= 0.041928,
		rollAngle		= -0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.907917,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.907917,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 37.846794,--FOV
		hAngle			= 51.644135,
		vAngle			= -51.870411,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 80.000000,--FOV
		hAngle			= 85.327867,
		vAngle			= -35.035887,
		x_trans			= 0.016031,
		y_trans			= -0.053119,
		z_trans			= -0.023044,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 56.840000,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= -0.190692,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.348198,--FOV
		hAngle			= 109.752129,
		vAngle			= 1.484382,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= -0.150335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 56.840000,--FOV
		hAngle			= -93.365396,
		vAngle			= -30.892378,
		x_trans			= -0.180876,
		y_trans			= -0.027986,
		z_trans			= -0.089313,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 56.840000,--FOV
		hAngle			= -62.375701,
		vAngle			= -30.892378,
		x_trans			= 0.206142,
		y_trans			= -0.122487,
		z_trans			= -0.103071,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -17.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 37.846794,--FOV
		hAngle			= 51.644135,
		vAngle			= -51.870411,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 36.178646,--FOV
		hAngle			= -1.912186,
		vAngle			= -34.446247,
		x_trans			= 0.000000,
		y_trans			= -0.025421,
		z_trans			= 0.073226,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 90.348198,--FOV
		hAngle			= 0.000000,
		vAngle			= -90.000000,
		x_trans			= -4.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 73.605141,--FOV
		hAngle			= -90.361992,
		vAngle			= -44.103138,
		x_trans			= 0.169696,
		y_trans			= -0.073508,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.042202,
		x_trans			= 0.142145,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= -0.120000,
		y_trans			= 0.030000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Mi-8MT"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 29.415312,--FOV
		hAngle			= -93.376801,
		vAngle			= 9.582571,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 54.240440,--FOV
		hAngle			= 0.000000,
		vAngle			= -29.486044,
		x_trans			= 0.000000,
		y_trans			= -0.089093,
		z_trans			= -0.019368,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 44.628349,--FOV
		hAngle			= -58.224052,
		vAngle			= -52.560867,
		x_trans			= 0.000000,
		y_trans			= 0.067124,
		z_trans			= 0.016026,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 56.762150,--FOV
		hAngle			= 31.801413,
		vAngle			= 102.962082,
		x_trans			= 0.000000,
		y_trans			= -0.050205,
		z_trans			= -0.024370,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 39.324799,--FOV
		hAngle			= 4.669143,
		vAngle			= -1.769594,
		x_trans			= 0.000000,
		y_trans			= 0.067124,
		z_trans			= 0.016026,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 50.895313,--FOV
		hAngle			= -48.569939,
		vAngle			= 25.302469,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 81.069313,--FOV
		hAngle			= 0.352628,
		vAngle			= 62.929485,
		x_trans			= 0.000000,
		y_trans			= 0.135126,
		z_trans			= 0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 59.741261,--FOV
		hAngle			= 0.000000,
		vAngle			= 41.349342,
		x_trans			= 0.000000,
		y_trans			= -0.050205,
		z_trans			= -0.004188,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 28.216700,--FOV
		hAngle			= -76.491844,
		vAngle			= 9.112473,
		x_trans			= 0.000000,
		y_trans			= -0.050205,
		z_trans			= -0.024370,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.907917,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.907917,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.042202,
		x_trans			= 0.142145,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 51.882027,--FOV
		hAngle			= 0.000000,
		vAngle			= -33.841507,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.039255,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 50.878792,--FOV
		hAngle			= 32.860058,
		vAngle			= -55.928726,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.150935,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 105.118645,--FOV
		hAngle			= -71.647652,
		vAngle			= 24.494265,
		x_trans			= -0.200000,
		y_trans			= 0.106347,
		z_trans			= -0.087076,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 95.648193,--FOV
		hAngle			= 0.000000,
		vAngle			= 38.719566,
		x_trans			= 0.000000,
		y_trans			= 0.223433,
		z_trans			= -0.217264,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 37.623142,--FOV
		hAngle			= -90.631958,
		vAngle			= -54.782791,
		x_trans			= 0.101180,
		y_trans			= 0.010971,
		z_trans			= -0.017066,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 36.178646,--FOV
		hAngle			= -1.912186,
		vAngle			= -34.446247,
		x_trans			= 0.000000,
		y_trans			= -0.025421,
		z_trans			= 0.073226,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 59.177391,--FOV
		hAngle			= 0.000000,
		vAngle			= -68.848579,
		x_trans			= 0.309461,
		y_trans			= -0.200000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 64.097542,--FOV
		hAngle			= 74.783432,
		vAngle			= 1.446533,
		x_trans			= 0.000000,
		y_trans			= 0.220472,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.348198,--FOV
		hAngle			= 109.752129,
		vAngle			= 1.484382,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= -0.150335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 73.143143,--FOV
		hAngle			= 0.000000,
		vAngle			= 52.365082,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.141813,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.042202,
		x_trans			= 0.142145,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[4] = {-- player slot 4
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-15bis"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 68.620003,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.821661,
		x_trans			= 0.019947,
		y_trans			= -0.149997,
		z_trans			= 0.010006,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.333851,--FOV
		hAngle			= 122.330452,
		vAngle			= -32.738903,
		x_trans			= 0.143506,
		y_trans			= -0.140608,
		z_trans			= 0.120701,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 38.077599,--FOV
		hAngle			= 13.129223,
		vAngle			= -43.953190,
		x_trans			= 0.014712,
		y_trans			= -0.147237,
		z_trans			= 0.151673,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 63.835899,--FOV
		hAngle			= -124.195015,
		vAngle			= -34.234421,
		x_trans			= 0.150283,
		y_trans			= -0.139996,
		z_trans			= -0.122656,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 72.577103,--FOV
		hAngle			= 58.758263,
		vAngle			= -43.906391,
		x_trans			= 0.166430,
		y_trans			= -0.092155,
		z_trans			= 0.040978,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 79.531250,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= -0.002405,
		y_trans			= 0.035586,
		z_trans			= 0.002460,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 43.300751,--FOV
		hAngle			= -39.556873,
		vAngle			= -26.867842,
		x_trans			= 0.000000,
		y_trans			= -0.149016,
		z_trans			= -0.082786,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= 0.005478,
		y_trans			= 0.075000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.591541,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.700000,
		x_trans			= -0.050000,
		y_trans			= 0.032000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.700000,
		x_trans			= -0.050000,
		y_trans			= 0.032000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-19P"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 80.368210,--FOV
		hAngle			= 85.393799,
		vAngle			= -41.486076,
		x_trans			= 0.157451,
		y_trans			= -0.100000,
		z_trans			= -0.009519,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 63.256199,--FOV
		hAngle			= 1.426592,
		vAngle			= -41.719070,
		x_trans			= 0.085901,
		y_trans			= -0.100000,
		z_trans			= -0.009519,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 76.647797,--FOV
		hAngle			= -78.749481,
		vAngle			= -29.502331,
		x_trans			= -0.049830,
		y_trans			= -0.099289,
		z_trans			= -0.062558,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 43.459999,--FOV
		hAngle			= 82.600830,
		vAngle			= -35.738941,
		x_trans			= 0.249050,
		y_trans			= -0.100000,
		z_trans			= 0.027912,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 33.927799,--FOV
		hAngle			= -88.687584,
		vAngle			= -37.901005,
		x_trans			= 0.074872,
		y_trans			= -0.099864,
		z_trans			= -0.081359,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.368210,--FOV
		hAngle			= -28.769905,
		vAngle			= -48.026943,
		x_trans			= 0.003241,
		y_trans			= -0.008194,
		z_trans			= -0.001984,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 43.459999,--FOV
		hAngle			= -73.645126,
		vAngle			= -35.550064,
		x_trans			= 0.248315,
		y_trans			= -0.100000,
		z_trans			= -0.001678,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-21Bis"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 70.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 74.748451,--FOV
		hAngle			= 68.830132,
		vAngle			= -44.170761,
		x_trans			= 0.117387,
		y_trans			= -0.103918,
		z_trans			= -0.037340,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 61.616852,--FOV
		hAngle			= -65.951721,
		vAngle			= -34.509018,
		x_trans			= 0.000000,
		y_trans			= -0.035368,
		z_trans			= -0.103254,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 85.000000,--FOV
		hAngle			= 80.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 55.753201,--FOV
		hAngle			= 0.000000,
		vAngle			= -11.925499,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 85.000000,--FOV
		hAngle			= -80.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 85.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 85.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 85.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 90.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.015000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 90.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.015000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-29A"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 76.124840,--FOV
		hAngle			= -2.623254,
		vAngle			= -26.566959,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 34.911949,--FOV
		hAngle			= 24.601770,
		vAngle			= -32.350807,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 26.184198,--FOV
		hAngle			= 12.026249,
		vAngle			= -40.075508,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 39.454399,--FOV
		hAngle			= -26.664328,
		vAngle			= -32.355324,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 81.240005,--FOV
		hAngle			= 131.503998,
		vAngle			= 10.804660,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 44.201855,--FOV
		hAngle			= 0.000000,
		vAngle			= -2.378299,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 81.240005,--FOV
		hAngle			= -131.503998,
		vAngle			= 10.804660,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 81.240005,--FOV
		hAngle			= 76.013145,
		vAngle			= 2.248441,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= 36.304676,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 81.240005,--FOV
		hAngle			= -74.774559,
		vAngle			= 2.248441,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= 13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= -13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-29G"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 76.124840,--FOV
		hAngle			= -2.623254,
		vAngle			= -26.566959,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 34.911949,--FOV
		hAngle			= 24.601770,
		vAngle			= -32.350807,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 26.184198,--FOV
		hAngle			= 12.026249,
		vAngle			= -40.075508,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 39.454399,--FOV
		hAngle			= -26.664328,
		vAngle			= -32.355324,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 81.240005,--FOV
		hAngle			= 131.503998,
		vAngle			= 10.804660,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 44.201855,--FOV
		hAngle			= 0.000000,
		vAngle			= -2.378299,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 81.240005,--FOV
		hAngle			= -131.503998,
		vAngle			= 10.804660,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 81.240005,--FOV
		hAngle			= 76.013145,
		vAngle			= 2.248441,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= 36.304676,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 81.240005,--FOV
		hAngle			= -74.774559,
		vAngle			= 2.248441,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= 13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= -13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-29K"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -26.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 30.000000,--FOV
		hAngle			= 20.000000,
		vAngle			= -43.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 30.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -43.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 30.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= -43.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 30.000000,--FOV
		hAngle			= 20.000000,
		vAngle			= -23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 30.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 30.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= -23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 30.000000,--FOV
		hAngle			= 20.000000,
		vAngle			= 2.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 30.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 2.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 30.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 2.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= 13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= -13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MiG-29S"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 76.124840,--FOV
		hAngle			= -2.623254,
		vAngle			= -26.566959,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 34.911949,--FOV
		hAngle			= 24.601770,
		vAngle			= -32.350807,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 26.184198,--FOV
		hAngle			= 12.026249,
		vAngle			= -40.075508,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 39.454399,--FOV
		hAngle			= -26.664328,
		vAngle			= -32.355324,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 81.240005,--FOV
		hAngle			= 131.503998,
		vAngle			= 10.804660,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 44.201855,--FOV
		hAngle			= 0.000000,
		vAngle			= -2.378299,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 81.240005,--FOV
		hAngle			= -131.503998,
		vAngle			= 10.804660,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 81.240005,--FOV
		hAngle			= 76.013145,
		vAngle			= 2.248441,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= 36.304676,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 81.240005,--FOV
		hAngle			= -74.774559,
		vAngle			= 2.248441,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= 13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 68.250000,--FOV
		hAngle			= -13.070938,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 81.240005,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["MosquitoFBMkVI"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 53.900002,
		vAngle			= -52.500000,
		x_trans			= 0.100000,
		y_trans			= 0.000000,
		z_trans			= -0.100000,
		rollAngle		= -10.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 45.320000,--FOV
		hAngle			= 0.000000,
		vAngle			= -73.697486,
		x_trans			= 0.461216,
		y_trans			= -0.017754,
		z_trans			= -0.085847,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 50.000000,--FOV
		hAngle			= -55.599998,
		vAngle			= -41.200001,
		x_trans			= 0.000000,
		y_trans			= -0.091000,
		z_trans			= 0.033000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.000000,--FOV
		hAngle			= 150.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 1.500000,
		x_trans			= 0.225000,
		y_trans			= 0.011000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -150.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 22.794298,
		vAngle			= -22.210251,
		x_trans			= 0.000000,
		y_trans			= 0.047437,
		z_trans			= -0.122030,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.152000,
		y_trans			= 0.066000,
		z_trans			= -0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -24.224000,
		vAngle			= -20.320000,
		x_trans			= 0.000000,
		y_trans			= 0.041333,
		z_trans			= 0.591111,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.045000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 48.560001,--FOV
		hAngle			= 159.045807,
		vAngle			= -51.171925,
		x_trans			= 0.297462,
		y_trans			= -0.182377,
		z_trans			= -0.173760,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 61.580000,--FOV
		hAngle			= 131.208063,
		vAngle			= -56.252580,
		x_trans			= 0.053520,
		y_trans			= -0.138833,
		z_trans			= 0.017208,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 50.000000,--FOV
		hAngle			= -55.599998,
		vAngle			= -41.200001,
		x_trans			= 0.000000,
		y_trans			= -0.091000,
		z_trans			= 0.033000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 1.500000,
		x_trans			= 0.225000,
		y_trans			= 0.011000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 150.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -7.000000,
		x_trans			= 0.152000,
		y_trans			= 0.066000,
		z_trans			= -0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 56.593850,--FOV
		hAngle			= 101.333162,
		vAngle			= -3.372503,
		x_trans			= -0.086077,
		y_trans			= -0.007343,
		z_trans			= 0.250200,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.045000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["P-51D"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -75.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 20.000000,--FOV
		hAngle			= 176.919998,
		vAngle			= -16.804399,
		x_trans			= 0.450000,
		y_trans			= 0.126814,
		z_trans			= -0.220000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -143.000000,
		vAngle			= 0.000000,
		x_trans			= 0.350000,
		y_trans			= 0.059000,
		z_trans			= 0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["P-51D-30-NA"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -75.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 20.000000,--FOV
		hAngle			= 176.919998,
		vAngle			= -16.804399,
		x_trans			= 0.450000,
		y_trans			= 0.126814,
		z_trans			= -0.220000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -143.000000,
		vAngle			= 0.000000,
		x_trans			= 0.350000,
		y_trans			= 0.059000,
		z_trans			= 0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["SA342L"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 42.080002,--FOV
		hAngle			= 148.767395,
		vAngle			= -65.000000,
		x_trans			= 0.041618,
		y_trans			= 0.000000,
		z_trans			= -0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 37.625549,--FOV
		hAngle			= 0.000000,
		vAngle			= -51.918274,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.199706,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 65.358147,--FOV
		hAngle			= 0.067279,
		vAngle			= -56.732319,
		x_trans			= 0.598976,
		y_trans			= 0.008428,
		z_trans			= -0.115248,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 43.649750,--FOV
		hAngle			= 35.042400,
		vAngle			= -27.641199,
		x_trans			= 0.592900,
		y_trans			= -0.197568,
		z_trans			= 0.197568,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -28.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 55.020149,--FOV
		hAngle			= -26.989201,
		vAngle			= -28.034105,
		x_trans			= 0.041861,
		y_trans			= -0.001470,
		z_trans			= -0.199034,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 45.831150,--FOV
		hAngle			= -34.056206,
		vAngle			= -41.788696,
		x_trans			= -0.117539,
		y_trans			= -0.197568,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 35.831402,--FOV
		hAngle			= -101.221565,
		vAngle			= -65.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 67.780647,--FOV
		hAngle			= -11.945637,
		vAngle			= -26.743050,
		x_trans			= 0.140238,
		y_trans			= 0.000000,
		z_trans			= 0.199865,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -57.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 84.000000,--FOV
		hAngle			= 105.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 84.000000,--FOV
		hAngle			= -135.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 84.000000,--FOV
		hAngle			= -90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["SA342M"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 42.080002,--FOV
		hAngle			= 148.767395,
		vAngle			= -65.000000,
		x_trans			= 0.041618,
		y_trans			= 0.000000,
		z_trans			= -0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 37.625549,--FOV
		hAngle			= 0.000000,
		vAngle			= -51.918274,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.199706,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 65.358147,--FOV
		hAngle			= 0.067279,
		vAngle			= -56.732319,
		x_trans			= 0.598976,
		y_trans			= 0.008428,
		z_trans			= -0.115248,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 43.649750,--FOV
		hAngle			= 35.042400,
		vAngle			= -27.641199,
		x_trans			= 0.592900,
		y_trans			= -0.197568,
		z_trans			= 0.197568,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -28.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 55.020149,--FOV
		hAngle			= -26.989201,
		vAngle			= -28.034105,
		x_trans			= 0.041861,
		y_trans			= -0.001470,
		z_trans			= -0.199034,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 45.831150,--FOV
		hAngle			= -34.056206,
		vAngle			= -41.788696,
		x_trans			= -0.117539,
		y_trans			= -0.197568,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 35.831402,--FOV
		hAngle			= -101.221565,
		vAngle			= -65.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 67.780647,--FOV
		hAngle			= -11.945637,
		vAngle			= -26.743050,
		x_trans			= 0.140238,
		y_trans			= 0.000000,
		z_trans			= 0.199865,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -57.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 84.000000,--FOV
		hAngle			= 105.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 84.000000,--FOV
		hAngle			= -135.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 84.000000,--FOV
		hAngle			= -90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["SA342Minigun"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 84.000000,--FOV
		hAngle			= 105.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 84.000000,--FOV
		hAngle			= -135.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 84.000000,--FOV
		hAngle			= -90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -28.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 55.020149,--FOV
		hAngle			= -26.989201,
		vAngle			= -28.034105,
		x_trans			= 0.041861,
		y_trans			= -0.001470,
		z_trans			= -0.199034,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 45.831150,--FOV
		hAngle			= -34.056206,
		vAngle			= -41.788696,
		x_trans			= -0.117539,
		y_trans			= -0.197568,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 35.831402,--FOV
		hAngle			= -101.221565,
		vAngle			= -65.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 84.000000,--FOV
		hAngle			= -90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.400000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -57.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 84.000000,--FOV
		hAngle			= 105.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 84.000000,--FOV
		hAngle			= -135.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 84.000000,--FOV
		hAngle			= -90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["SA342Mistral"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 42.080002,--FOV
		hAngle			= 148.767395,
		vAngle			= -65.000000,
		x_trans			= 0.041618,
		y_trans			= 0.000000,
		z_trans			= -0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 37.625549,--FOV
		hAngle			= 0.000000,
		vAngle			= -51.918274,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.199706,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 65.358147,--FOV
		hAngle			= 0.067279,
		vAngle			= -56.732319,
		x_trans			= 0.598976,
		y_trans			= 0.008428,
		z_trans			= -0.115248,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 43.649750,--FOV
		hAngle			= 35.042400,
		vAngle			= -27.641199,
		x_trans			= 0.592900,
		y_trans			= -0.197568,
		z_trans			= 0.197568,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.095000,
		y_trans			= 0.000000,
		z_trans			= -0.004000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -13.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -28.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 55.020149,--FOV
		hAngle			= -26.989201,
		vAngle			= -28.034105,
		x_trans			= 0.041861,
		y_trans			= -0.001470,
		z_trans			= -0.199034,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 45.831150,--FOV
		hAngle			= -34.056206,
		vAngle			= -41.788696,
		x_trans			= -0.117539,
		y_trans			= -0.197568,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 35.831402,--FOV
		hAngle			= -101.221565,
		vAngle			= -65.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 67.780647,--FOV
		hAngle			= -11.945637,
		vAngle			= -26.743050,
		x_trans			= 0.140238,
		y_trans			= 0.000000,
		z_trans			= 0.199865,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -57.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 84.000000,--FOV
		hAngle			= 105.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 65.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 84.000000,--FOV
		hAngle			= -135.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 84.000000,--FOV
		hAngle			= 90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 84.000000,--FOV
		hAngle			= -90.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 84.000000,--FOV
		hAngle			= 58.000000,
		vAngle			= 23.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 35.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 84.000000,--FOV
		hAngle			= -38.000000,
		vAngle			= 25.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 84.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -8.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 84.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["SpitfireLFMkIX"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 50.700001,
		vAngle			= -56.000000,
		x_trans			= 0.137000,
		y_trans			= -0.036000,
		z_trans			= -0.041000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 33.439999,--FOV
		hAngle			= -12.263295,
		vAngle			= -44.226139,
		x_trans			= 0.187600,
		y_trans			= -0.006461,
		z_trans			= -0.154534,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= -50.700001,
		vAngle			= -56.000000,
		x_trans			= 0.137000,
		y_trans			= -0.036000,
		z_trans			= 0.041000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.000000,--FOV
		hAngle			= 160.000000,
		vAngle			= 0.000000,
		x_trans			= 0.314000,
		y_trans			= 0.000000,
		z_trans			= -0.155000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 55.099998,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.200000,
		y_trans			= 0.025000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -160.000000,
		vAngle			= 0.000000,
		x_trans			= 0.314000,
		y_trans			= 0.000000,
		z_trans			= 0.155000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.738133,
		x_trans			= -0.070867,
		y_trans			= 0.076533,
		z_trans			= -0.154400,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.222000,
		y_trans			= 0.056000,
		z_trans			= -0.021000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.738133,
		x_trans			= -0.070956,
		y_trans			= 0.076800,
		z_trans			= 0.154933,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 33.400002,
		x_trans			= 0.075000,
		y_trans			= 0.060000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["SpitfireLFMkIXCW"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 60.000000,--FOV
		hAngle			= 50.700001,
		vAngle			= -56.000000,
		x_trans			= 0.137000,
		y_trans			= -0.036000,
		z_trans			= -0.041000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 63.400002,--FOV
		hAngle			= 3.000000,
		vAngle			= -27.299999,
		x_trans			= 0.123000,
		y_trans			= -0.038000,
		z_trans			= 0.042000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 60.000000,--FOV
		hAngle			= -50.700001,
		vAngle			= -56.000000,
		x_trans			= 0.137000,
		y_trans			= -0.036000,
		z_trans			= 0.041000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.000000,--FOV
		hAngle			= 160.000000,
		vAngle			= 0.000000,
		x_trans			= 0.314000,
		y_trans			= 0.000000,
		z_trans			= -0.155000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 55.099998,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.200000,
		y_trans			= 0.025000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -160.000000,
		vAngle			= 0.000000,
		x_trans			= 0.314000,
		y_trans			= 0.000000,
		z_trans			= 0.155000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.222000,
		y_trans			= 0.056000,
		z_trans			= -0.021000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 33.400002,
		x_trans			= 0.075000,
		y_trans			= 0.060000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.075000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Su-25"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 68.767799,--FOV
		hAngle			= 1.929517,
		vAngle			= -30.846605,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 29.223452,--FOV
		hAngle			= 37.489525,
		vAngle			= -38.883888,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 40.635601,--FOV
		hAngle			= -0.438357,
		vAngle			= -33.138290,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 24.797405,--FOV
		hAngle			= -34.382549,
		vAngle			= -34.808853,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 69.302101,--FOV
		hAngle			= 89.405373,
		vAngle			= 1.213156,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 29.761202,--FOV
		hAngle			= 0.000000,
		vAngle			= -6.880077,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 69.302101,--FOV
		hAngle			= -89.691940,
		vAngle			= 4.554290,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 69.302101,--FOV
		hAngle			= 52.113377,
		vAngle			= -3.970644,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 72.856201,--FOV
		hAngle			= 0.000000,
		vAngle			= 30.866713,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 69.302101,--FOV
		hAngle			= -50.664936,
		vAngle			= -3.970644,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 47.680202,--FOV
		hAngle			= 43.054649,
		vAngle			= -7.799250,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 47.680202,--FOV
		hAngle			= -41.743240,
		vAngle			= -7.799250,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 69.302101,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.137112,
		x_trans			= 0.050000,
		y_trans			= -0.031239,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 69.302101,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.137112,
		x_trans			= 0.050000,
		y_trans			= 0.010000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Su-25T"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.663399,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.619938,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 39.764698,--FOV
		hAngle			= 28.661316,
		vAngle			= -41.406044,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 38.090847,--FOV
		hAngle			= -24.622110,
		vAngle			= -45.153934,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 33.645596,--FOV
		hAngle			= -36.653450,
		vAngle			= -23.703861,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.663399,--FOV
		hAngle			= 99.816956,
		vAngle			= 8.032285,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 58.718098,--FOV
		hAngle			= 0.000000,
		vAngle			= -5.000803,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.663399,--FOV
		hAngle			= -99.999687,
		vAngle			= 8.032285,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.663399,--FOV
		hAngle			= 58.382488,
		vAngle			= -6.648195,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 94.037704,--FOV
		hAngle			= 0.000000,
		vAngle			= 41.421227,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.663399,--FOV
		hAngle			= -57.531212,
		vAngle			= -6.648195,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.203396,--FOV
		hAngle			= 55.124939,
		vAngle			= -8.400513,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.203396,--FOV
		hAngle			= -52.633553,
		vAngle			= -8.400513,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 90.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.382137,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 90.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.382137,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Su-25TM"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.663399,--FOV
		hAngle			= 0.000000,
		vAngle			= -30.619938,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 39.764698,--FOV
		hAngle			= 28.661316,
		vAngle			= -41.406044,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 38.090847,--FOV
		hAngle			= -24.622110,
		vAngle			= -45.153934,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 33.645596,--FOV
		hAngle			= -36.653450,
		vAngle			= -23.703861,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 80.663399,--FOV
		hAngle			= 99.816956,
		vAngle			= 8.032285,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 58.718098,--FOV
		hAngle			= 0.000000,
		vAngle			= -5.000803,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.663399,--FOV
		hAngle			= -99.999687,
		vAngle			= 8.032285,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.663399,--FOV
		hAngle			= 58.382488,
		vAngle			= -6.648195,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 94.037704,--FOV
		hAngle			= 0.000000,
		vAngle			= 41.421227,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.663399,--FOV
		hAngle			= -57.531212,
		vAngle			= -6.648195,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 60.203396,--FOV
		hAngle			= 55.124939,
		vAngle			= -8.400513,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 60.203396,--FOV
		hAngle			= -52.633553,
		vAngle			= -8.400513,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 90.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.382137,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 90.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -18.382137,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Su-27"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 71.824692,--FOV
		hAngle			= 0.000000,
		vAngle			= -32.458889,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 33.361835,--FOV
		hAngle			= 41.045925,
		vAngle			= -40.805656,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 30.427544,--FOV
		hAngle			= 0.000000,
		vAngle			= -41.808968,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 34.392349,--FOV
		hAngle			= -32.597401,
		vAngle			= -35.293747,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 87.468338,--FOV
		hAngle			= 129.012665,
		vAngle			= 14.547977,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 43.977936,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.951577,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 87.468338,--FOV
		hAngle			= -129.012665,
		vAngle			= 14.491872,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 87.468338,--FOV
		hAngle			= 82.862923,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= 38.979362,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 87.468338,--FOV
		hAngle			= -82.461266,
		vAngle			= -12.843998,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.786629,--FOV
		hAngle			= 15.618313,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 69.165199,--FOV
		hAngle			= -15.683434,
		vAngle			= 8.549150,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Su-33"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 71.824692,--FOV
		hAngle			= 0.000000,
		vAngle			= -32.458889,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 38.591434,--FOV
		hAngle			= 42.504570,
		vAngle			= -42.790123,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 30.427544,--FOV
		hAngle			= 0.000000,
		vAngle			= -41.808968,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 34.392349,--FOV
		hAngle			= -32.597401,
		vAngle			= -35.293747,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 87.468338,--FOV
		hAngle			= 129.012665,
		vAngle			= 14.547977,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 43.977936,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.951577,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 87.468338,--FOV
		hAngle			= -129.012665,
		vAngle			= 14.491872,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 87.468338,--FOV
		hAngle			= 82.862923,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= 38.979362,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 87.468338,--FOV
		hAngle			= -82.461266,
		vAngle			= -12.843998,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.786629,--FOV
		hAngle			= 15.618313,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 69.165199,--FOV
		hAngle			= -15.683434,
		vAngle			= 8.549150,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["T-45"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 79.400000,--FOV
		hAngle			= 43.643937,
		vAngle			= -45.673852,
		x_trans			= -0.148331,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 74.600000,--FOV
		hAngle			= 5.046067,
		vAngle			= -15.480348,
		x_trans			= 0.036667,
		y_trans			= -0.299929,
		z_trans			= 0.136575,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 53.420000,--FOV
		hAngle			= -44.006252,
		vAngle			= -52.995502,
		x_trans			= -0.138206,
		y_trans			= -0.041037,
		z_trans			= 0.036424,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 79.400000,--FOV
		hAngle			= 43.643937,
		vAngle			= -45.673852,
		x_trans			= -0.148331,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 53.420000,--FOV
		hAngle			= -44.006252,
		vAngle			= -52.995502,
		x_trans			= -0.138206,
		y_trans			= -0.041037,
		z_trans			= 0.036424,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 81.368900,--FOV
		hAngle			= 47.982192,
		vAngle			= -55.488659,
		x_trans			= -0.021965,
		y_trans			= 0.020000,
		z_trans			= -0.005296,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 95.048900,--FOV
		hAngle			= 7.745970,
		vAngle			= -21.114036,
		x_trans			= 0.039412,
		y_trans			= -0.244231,
		z_trans			= 0.114240,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 46.280000,--FOV
		hAngle			= -48.375052,
		vAngle			= -59.989005,
		x_trans			= -0.031256,
		y_trans			= 0.020256,
		z_trans			= 0.002258,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 81.368900,--FOV
		hAngle			= 47.982192,
		vAngle			= -55.488659,
		x_trans			= -0.021965,
		y_trans			= 0.020000,
		z_trans			= -0.005296,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 46.280000,--FOV
		hAngle			= -48.375052,
		vAngle			= -59.989005,
		x_trans			= -0.031256,
		y_trans			= 0.020256,
		z_trans			= 0.002258,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 75.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.000000,
		x_trans			= 0.000000,
		y_trans			= 0.020000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},  
}
SnapViews["TF-51D"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -75.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -45.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.040001,--FOV
		hAngle			= 157.332764,
		vAngle			= -28.359503,
		x_trans			= 0.063872,
		y_trans			= 0.082888,
		z_trans			= -0.116148,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 50.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -8.722581,
		x_trans			= 0.212078,
		y_trans			= 0.057813,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 80.000000,--FOV
		hAngle			= -143.000000,
		vAngle			= 0.000000,
		x_trans			= 0.350000,
		y_trans			= 0.059000,
		z_trans			= 0.100000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 80.000000,--FOV
		hAngle			= 45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 80.000000,--FOV
		hAngle			= -45.000000,
		vAngle			= -5.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 10.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 80.000000,--FOV
		hAngle			= -20.000000,
		vAngle			= 8.000000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 80.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.120000,
		y_trans			= 0.059000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["UH-1H"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 60.000000,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 36.178646,--FOV
		hAngle			= -1.912186,
		vAngle			= -34.446247,
		x_trans			= 0.000000,
		y_trans			= -0.025421,
		z_trans			= 0.073226,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 70.063347,--FOV
		hAngle			= 58.066902,
		vAngle			= -65.247879,
		x_trans			= 0.255946,
		y_trans			= 0.003003,
		z_trans			= -0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 73.605141,--FOV
		hAngle			= -90.361992,
		vAngle			= -44.103138,
		x_trans			= 0.169696,
		y_trans			= -0.073508,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.348198,--FOV
		hAngle			= 109.752129,
		vAngle			= 1.484382,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= -0.150335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 73.850960,--FOV
		hAngle			= 64.868401,
		vAngle			= 50.408779,
		x_trans			= -0.098762,
		y_trans			= -0.035863,
		z_trans			= -0.199938,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.592758,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= -15.592758,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[2] = {-- player slot 2
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 37.846794,--FOV
		hAngle			= 51.644135,
		vAngle			= -51.870411,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 81.967491,--FOV
		hAngle			= -5.037267,
		vAngle			= -63.153660,
		x_trans			= -0.040542,
		y_trans			= 0.000000,
		z_trans			= 0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 36.178646,--FOV
		hAngle			= -1.912186,
		vAngle			= -34.446247,
		x_trans			= 0.000000,
		y_trans			= -0.025421,
		z_trans			= 0.073226,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.348198,--FOV
		hAngle			= 109.752129,
		vAngle			= 1.484382,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= -0.150335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 86.465691,--FOV
		hAngle			= -53.235435,
		vAngle			= 45.482685,
		x_trans			= -0.200000,
		y_trans			= 0.000000,
		z_trans			= 0.200000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[3] = {-- player slot 3
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 37.846794,--FOV
		hAngle			= 51.644135,
		vAngle			= -51.870411,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 36.178646,--FOV
		hAngle			= -1.912186,
		vAngle			= -34.446247,
		x_trans			= 0.000000,
		y_trans			= -0.025421,
		z_trans			= 0.073226,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 73.605141,--FOV
		hAngle			= -90.361992,
		vAngle			= -44.103138,
		x_trans			= 0.169696,
		y_trans			= -0.073508,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.348198,--FOV
		hAngle			= 109.752129,
		vAngle			= 1.484382,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= -0.150335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.042202,
		x_trans			= 0.142145,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
[4] = {-- player slot 4
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 67.452896,--FOV
		hAngle			= 15.000000,
		vAngle			= -20.067383,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 37.846794,--FOV
		hAngle			= 51.644135,
		vAngle			= -51.870411,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 36.178646,--FOV
		hAngle			= -1.912186,
		vAngle			= -34.446247,
		x_trans			= 0.000000,
		y_trans			= -0.025421,
		z_trans			= 0.073226,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 73.605141,--FOV
		hAngle			= -90.361992,
		vAngle			= -44.103138,
		x_trans			= 0.169696,
		y_trans			= -0.073508,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 91.348198,--FOV
		hAngle			= 109.752129,
		vAngle			= 1.484382,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= -0.150335,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 42.512844,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.478010,
		x_trans			= 0.154018,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 91.348198,--FOV
		hAngle			= -108.852020,
		vAngle			= 0.085984,
		x_trans			= 0.190306,
		y_trans			= 0.044778,
		z_trans			= 0.139404,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 89.777542,--FOV
		hAngle			= 16.411518,
		vAngle			= -27.209915,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= -0.218292,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 88.727844,--FOV
		hAngle			= 0.000000,
		vAngle			= 34.042202,
		x_trans			= 0.142145,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 59.208893,--FOV
		hAngle			= -32.128311,
		vAngle			= -5.720805,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= 14.803060,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 56.032040,--FOV
		hAngle			= -14.414484,
		vAngle			= 3.332499,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.033583,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 89.777542,--FOV
		hAngle			= 0.000000,
		vAngle			= 0.000000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
SnapViews["Yak-52"] = {
[1] = {-- player slot 1
	[1] = {--LWin + Num0 : Snap View 0
		viewAngle		= 71.824692,--FOV
		hAngle			= 0.000000,
		vAngle			= -32.458889,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[2] = {--LWin + Num1 : Snap View 1
		viewAngle		= 33.361835,--FOV
		hAngle			= 41.045925,
		vAngle			= -40.805656,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[3] = {--LWin + Num2 : Snap View 2
		viewAngle		= 30.427544,--FOV
		hAngle			= 0.000000,
		vAngle			= -41.808968,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[4] = {--LWin + Num3 : Snap View 3
		viewAngle		= 34.392349,--FOV
		hAngle			= -32.597401,
		vAngle			= -35.293747,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[5] = {--LWin + Num4 : Snap View 4
		viewAngle		= 87.468338,--FOV
		hAngle			= 129.012665,
		vAngle			= 14.547977,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[6] = {--LWin + Num5 : Snap View 5
		viewAngle		= 43.977936,--FOV
		hAngle			= 0.000000,
		vAngle			= -4.951577,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[7] = {--LWin + Num6 : Snap View 6
		viewAngle		= 87.468338,--FOV
		hAngle			= -129.012665,
		vAngle			= 14.491872,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[8] = {--LWin + Num7 : Snap View 7
		viewAngle		= 87.468338,--FOV
		hAngle			= 82.862923,
		vAngle			= -9.500000,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[9] = {--LWin + Num8 : Snap View 8
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= 38.979362,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[10] = {--LWin + Num9 : Snap View 9
		viewAngle		= 87.468338,--FOV
		hAngle			= -82.461266,
		vAngle			= -12.843998,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[11] = {--look at left  mirror
		viewAngle		= 68.786629,--FOV
		hAngle			= 15.618313,
		vAngle			= 7.522498,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[12] = {--look at right mirror
		viewAngle		= 69.165199,--FOV
		hAngle			= -15.683434,
		vAngle			= 8.549150,
		x_trans			= 0.000000,
		y_trans			= 0.000000,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[13] = {--default view
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
	[14] = {--default view - VR
		viewAngle		= 87.468338,--FOV
		hAngle			= 0.000000,
		vAngle			= -9.500000,
		x_trans			= 0.113927,
		y_trans			= -0.004946,
		z_trans			= 0.000000,
		rollAngle		= 0.000000,
		cockpit_version	= 0,
	},
},
}
